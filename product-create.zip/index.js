const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  // 1. Verificar el token JWT del header
  const token = event.headers.Authorization.split(' ')[1];
  let userId;
  
  try {
    const decoded = jwt.verify(token, 'secreto'); // Usa el mismo secreto que en login
    userId = decoded.userId;
  } catch (error) {
    return { statusCode: 401, body: JSON.stringify({ error: 'Token inválido' }) };
  }

  // 2. Extraer datos del producto
  const { name, brand, categories, price } = JSON.parse(event.body);

  // 3. Guardar en DynamoDB
  const newProduct = {
    uuid: uuidv4(),
    name,
    brand,
    categories,
    price,
    userId,  // ID del usuario que lo creó
    createdAt: new Date().toISOString()
  };

  await dynamoDB.put({
    TableName: 'Products',
    Item: newProduct
  }).promise();

  return {
    statusCode: 201,
    body: JSON.stringify({
      message: "Producto creado exitosamente",
      data: newProduct
    })
  };
};